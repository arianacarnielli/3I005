#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 29 16:48:04 2019

@author: 3525837
"""

import Projet_Bioinfo as pb
import numpy as np
import math




def logproba(liste_entiers, m):
    """
    """
    res = 0
    for nucleo in liste_entiers:
        res += math.log(m[nucleo])
    return res


def logprobafast(liste_count):
    """
    """
    m = [i / sum(liste_count) for i in liste_count]
    res = 0
    for i in range(len(liste_count)):
        res += (math.log(m[i]) * liste_count[i])
    return res

def code(m, k):
    """
    """
    res = 0
    puissance = k - 1
    for i in range (len(m)):
        res += pow(4, puissance - i) * m[i]
    return res
    
def inverse(i, k):
    """
    """
    res = []
    div = i
    for i in range(k - 1, -1, -1):
        res.append(div // pow(4, i))
        div = div % pow(4, i)
    return res

